
(function () {
  "use strict";

  const STORAGE_KEY = "vecia_cookie_consent_v1";
  const categories = ["analytics", "advertising", "personalization", "externalMedia"];

  function readConsent() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (_) {
      return null;
    }
  }

  function saveConsent(preferences, action) {
    const record = {
      version: 1,
      action,
      savedAt: new Date().toISOString(),
      necessary: true,
      preferences: {
        analytics: !!preferences.analytics,
        advertising: !!preferences.advertising,
        personalization: !!preferences.personalization,
        externalMedia: !!preferences.externalMedia
      }
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(record));
    document.dispatchEvent(new CustomEvent("vecia:consent-changed", { detail: record }));
    render();
  }

  function has(category) {
    if (category === "necessary") return true;
    const consent = readConsent();
    return !!(consent && consent.preferences && consent.preferences[category] === true);
  }

  function openSettings() {
    const panel = document.getElementById("vecia-cookie-panel");
    if (!panel) return;
    panel.hidden = false;
    panel.classList.add("is-open");
    const consent = readConsent();
    categories.forEach((category) => {
      const checkbox = panel.querySelector('[name="' + category + '"]');
      if (checkbox) checkbox.checked = !!(consent && consent.preferences && consent.preferences[category]);
    });
    panel.querySelector(".vecia-cookie-banner")?.setAttribute("hidden", "");
    panel.querySelector(".vecia-cookie-settings")?.removeAttribute("hidden");
  }

  function render() {
    const panel = document.getElementById("vecia-cookie-panel");
    if (!panel) return;
    const consent = readConsent();
    const banner = panel.querySelector(".vecia-cookie-banner");
    const settings = panel.querySelector(".vecia-cookie-settings");
    const reopen = document.getElementById("vecia-cookie-reopen");

    if (consent) {
      banner.hidden = true;
      settings.hidden = true;
      panel.classList.remove("is-open");
      reopen.hidden = false;
    } else {
      banner.hidden = false;
      settings.hidden = true;
      panel.classList.add("is-open");
      reopen.hidden = true;
    }
  }

  function mount() {
    if (document.getElementById("vecia-cookie-panel")) return;

    const panel = document.createElement("div");
    panel.id = "vecia-cookie-panel";
    panel.innerHTML = `
      <section class="vecia-cookie-banner" role="dialog" aria-modal="true" aria-labelledby="vecia-cookie-title">
        <div class="vecia-cookie-copy">
          <p class="vecia-cookie-eyebrow">VECIA JURISTAS</p>
          <h2 id="vecia-cookie-title">Configuración de cookies</h2>
          <p>Utilizamos almacenamiento técnico necesario para recordar esta elección. Las tecnologías opcionales —analítica, publicidad, personalización y contenido multimedia externo— permanecerán desactivadas hasta que las autorices.</p>
          <p><a href="politica-cookies.html">Leer la política de cookies</a></p>
        </div>
        <div class="vecia-cookie-actions">
          <button type="button" data-action="accept">Aceptar todas</button>
          <button type="button" data-action="reject">Rechazar todas</button>
          <button type="button" data-action="settings">Configurar</button>
        </div>
      </section>
      <section class="vecia-cookie-settings" role="dialog" aria-modal="true" aria-labelledby="vecia-cookie-settings-title" hidden>
        <h2 id="vecia-cookie-settings-title">Preferencias de privacidad</h2>
        <p>Las categorías opcionales están desactivadas inicialmente. Puedes cambiar tu elección en cualquier momento desde «Configurar cookies».</p>
        <div class="vecia-cookie-option"><div><strong>Necesarias</strong><small>Imprescindibles para funciones solicitadas y para recordar tus preferencias.</small></div><input type="checkbox" checked disabled aria-label="Cookies necesarias siempre activas"></div>
        <div class="vecia-cookie-option"><div><strong>Analíticas</strong><small>Permiten medir el uso de la web y mejorar sus contenidos.</small></div><input type="checkbox" name="analytics"></div>
        <div class="vecia-cookie-option"><div><strong>Publicidad</strong><small>Permiten medir o personalizar publicidad, si en el futuro se incorpora.</small></div><input type="checkbox" name="advertising"></div>
        <div class="vecia-cookie-option"><div><strong>Personalización</strong><small>Recuerdan preferencias no esenciales del visitante.</small></div><input type="checkbox" name="personalization"></div>
        <div class="vecia-cookie-option"><div><strong>Contenido multimedia externo</strong><small>Permiten cargar vídeos u otros contenidos de terceros, por ejemplo plataformas de vídeo.</small></div><input type="checkbox" name="externalMedia"></div>
        <div class="vecia-cookie-actions">
          <button type="button" data-action="save">Guardar selección</button>
          <button type="button" data-action="reject">Rechazar todas</button>
          <button type="button" data-action="accept">Aceptar todas</button>
        </div>
        <p class="vecia-cookie-small"><a href="politica-cookies.html">Consultar política de cookies</a></p>
      </section>`;
    document.body.appendChild(panel);

    const reopen = document.createElement("button");
    reopen.id = "vecia-cookie-reopen";
    reopen.type = "button";
    reopen.textContent = "Configurar cookies";
    reopen.setAttribute("aria-label", "Abrir configuración de cookies");
    reopen.hidden = true;
    document.body.appendChild(reopen);

    panel.addEventListener("click", function (event) {
      const button = event.target.closest("button[data-action]");
      if (!button) return;
      const action = button.dataset.action;

      if (action === "settings") {
        openSettings();
      } else if (action === "reject") {
        saveConsent({}, "reject");
      } else if (action === "accept") {
        saveConsent({
          analytics: true,
          advertising: true,
          personalization: true,
          externalMedia: true
        }, "accept");
      } else if (action === "save") {
        const preferences = {};
        categories.forEach((category) => {
          preferences[category] = !!panel.querySelector('[name="' + category + '"]')?.checked;
        });
        saveConsent(preferences, "custom");
      }
    });

    reopen.addEventListener("click", openSettings);
    render();
  }

  window.VECIAConsent = {
    has,
    get: readConsent,
    openSettings,
    onChange: function (callback) {
      document.addEventListener("vecia:consent-changed", function (event) {
        callback(event.detail);
      });
    }
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mount);
  } else {
    mount();
  }
})();
